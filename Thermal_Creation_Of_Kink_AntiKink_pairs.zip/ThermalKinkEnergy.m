%ThermalKinkEnergy.m
%A numerical scheme for calculating the energy
%This is called in ThermalKinkMain.m

DTf = (f-f_old)/dt;
DXf = diff(f)/dx;
DXf(N) = (f(1)-f(N))/dx;

V=(lambda/4)*(f.^2 - 1).^2;

E1=0.5*(DTf).^2;
E2=0.5*(DXf).^2;

E=sum(dx*(E1+E2+V));


