%ThermalKinkMain.m

%This is the main body of our code for studying thermal creation of
%kink-antikink pairs. The scale parameter must be specified before it is 
%executed

%The code for graphics can be supressed with the addition of %{
%before each segment



L=100; %lengthscale of X
N=512; %number of lattice intervals
lambda=0.5; %value of lambda
dx=L/N; %x-interval length
dt=dx/4; %time-interval for use in our sparse matrix
lam=lambda*dt^2; %adjusted lamdba for use in our numerical scheme
alpha=(dt/dx)^2; %for use in our sparse matrix
x=linspace(0,L,N);%creates linearly spaced vector

f= ones(N,1);  % allocate memory for f 
%define arrays for f_old and f_new 

f_new = zeros(N,1) ;

f_old = f;  


%creating the sparse matrix

d=ones(N-1,1); %for terms on the upper and lower diagonal
a=(2*(1-alpha)+lam)*eye(N,N); %middle part
b=(alpha)*(diag(d,1)+diag(d,-1)); %diagonals

M=a+b;

%With boundary condition f(x+L)=f(x)
M(N,1)=alpha;
M(1,N)=alpha;

%we create an initial configuration
%scale value between 0.7 and 1.3

s=scale*exp(2*pi*1i*rand(N,1))./[100*ones(1,5) 6:(N/2 + 1) (N/2):(-1):2]';
z=fft(s); % first fourier transform
f=real(z)-1; f_old=f; % updating the field

s=scale*exp(2*pi*1i*rand(N,1))*2*pi/L;
z=fft(s); % second fourier transform
f=f_old+real(z)*dt; % updating the field time derivative

%this is the potential energy 
V=(lambda/4)*(f.^2-1).^2;

%Initial configuration plot
figure
titlestring=sprintf('Initialised field configuration (scale=%0.2f)',...
    scale);
plot(x,f,'blue')
title(titlestring)
xlabel('X')
ylabel('f')
%}

%Initial field configuration plot
figure
titlestring=sprintf('Initial potential (scale=%0.2f)',scale);
plot(x,V,'red')
title(titlestring)
xlabel('X')
ylabel('V (potential)')
%}

%Initial field vs Initial Potential plot
figure
titlestring=sprintf('Initial field profile vs Intial Potential (scale=%0.2f)',...
    scale);
plot(x,f,'blue',x,V,'red')
title(titlestring)
xlabel('X')
legend('f (Scalar function)','V (Potential)')
%}

f_init = f; %saving our initial profile

%We thermalise the configuration

%Number of timesteps to thermalise the system
t2Thermal=10000;

%Initialising the array for observing energy stability
En=zeros(t2Thermal,1); 

for i=1:t2Thermal
    f_new = -f_old + M*f - lam*f.^3;
    f_old=f;
    f=f_new;
    ThermalKinkEnergy
    En(i)=E;
end

%The following will allow us to visually check our energy over the course 
%of our thermalisation to ensure stability
figure
plot(En)
titlestring=sprintf('Energy over the course of thermalisation (scale=%0.2f)'...
    ,scale);
title(titlestring)
xlabel('Timestep')
ylabel('E (Energy)')
%}


%Plot of our initial profile vs the thermalised profile we have obtained
figure
plot(x,f_init,'blue',x,f,'green')
titlestring=sprintf('Initial profile vs thermalised profile (scale=%0.2f)'...
    ,scale);
title(titlestring)
xlabel('X')
legend('Initial profile','Thermalised field')
%}

Energy=mean(En);


%We continue our run, and count the number of kinks periodically

kinkCountTime=20; %How often (in time steps) we'd like to count kinks
kinkCountNumber=10000; %The number of kink counts we want 
runTime=kinkCountTime*kinkCountNumber;
k=1; %an index for our array of kink counts
index=0; %an index to measure when we should count our kinks
countArray=zeros(kinkCountNumber,1); %initialising our array of kink counts

plotDesired=6; %number of subsequent graphs of the field we'd like
               %these are produced midway through the run
               
plotIndex=0; %An index that increases up to when sufficiently many plots
             %are created
counter1=0;
counter2=0;
counter3=0;
change1=0;
change2=0;
change3=0;
nKink_creation=0;



for timestep=1:runTime
    f_new = -f_old + M*f - lam*f.^3;
    f_old=f;
    f=f_new;
    
    index=index+1;
    if index==kinkCountTime;
        whereF=find(diff(sign(f)) > 0); %where does the sign change
        nkinksNaive = length(whereF); %number of such sign changes
        %whereF gives us the location of where sign changes occur
        %This is susceptible to short term fluctuations
        %We will eliminate those sign changes which last a short amount
        %of x-intervals from our array
        
        latLength=20; %minimum number of intervals before counting
        smallIntv=find(diff(whereF) < latLength); 
            %where are the short term (in x) changes
        nkinksSmall = length(smallIntv);
        
        nkinks=nkinksNaive-nkinksSmall; %eliminate the short term (x) sign changes
        countArray(k)=nkinks;
        k=k+1;
        index=0;
    end
    
    %so we need to eliminate false events 9lasting less than 60 steps.
    %to do this I will set up  a script that will start a count every time the
    %kink count changes
    if (k>1)&&(k<(kinkCountNumber)+1) %to ensure proper behaviour
        oldnkinks=countArray(k-1);
        newkinks=countArray(k);
        %this triggers if a Kinks is created or destroyed
        if oldnkinks ~= newkinks
            
            difference = (oldnkinks-newkinks);
            %as we have to look a head 60 steps (and count the nkinks every 20) I have
            %set up 3 counters in case there is a change within those 60 steps. The
            %changes record how many kinks were created/destroyed
            %counter1 if there is a change
            if counter1==0
                counter1 = timestep +60;
                change1 = (oldnkinks-newkinks);
            end
            
            %counter 2 is triggered if there is a change within a change
            if (counter1~=0 || counter2==0)
                counter2 = timestep +60;
                change2 = (oldnkinks-newkinks);
            end
            %counter 3 if there is a change within a change in a change
            if (counter2~=0)
                counter3 = timestep +60;
                change3 = (oldnkinks-newkinks);
            end
            %this triggers if there wasn't a false event
            if (difference ~= change1)
                if (difference==change2)
                    change2=change3;
                    counter2=counter3;
                    change3=0;
                    counter3=0;
                end
                if(difference~=change2)
                    if difference==change3
                        change3=0;
                        counter3=0;
                    end
                end
            end
            %this triggers if there was a false event
            if (difference==change1)
                counter1=0;
                if counter2~=0
                    counter1=counter2;
                    counter2=counter3;
                    counter3=0;
                    
                    change1=change2;
                    change2=change3;
                    change3=0;
                end
            end
            %this triggers if there wasn't a false event and updates the nkink creation
            %number
            if (timestep == counter1)
                nKink_creation = nKink_creation +abs(change1);
                counter1=counter2;
                counter2=counter3;
                counter3=0;
                
                change1=change2;
                change2=change3;
                change3=0;
            end
            oldnkinks=newkinks;
        end
    end
    
    

    
    %This will plot the field and potential together for the first
    %multiples of 100, up to the number of plots desired (plotDesired)
    
    if (mod(timestep,100)==0)&&(plotIndex<plotDesired)
        figure
        titlestring=sprintf('Field configuration at t=%d (scale=%0.2f)',...
            timestep,scale);
        plot(x,f)
        title(titlestring)
        xlabel('X')
        ylabel('f')
        plotIndex=plotIndex+1;
    end
    %}
    
end

nkinkCreationTime=runTime/nKink_creation;



