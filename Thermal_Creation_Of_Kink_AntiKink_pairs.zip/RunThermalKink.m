%RunThermalKink.m

%This code runs out code through all values of the scale factor

ourIndex=1;
for scale=0.7:0.1:1.3
    scaleArray(ourIndex)=scale;
    ThermalKinkMain
    energyArray(ourIndex)=Energy;
    Gamma(ourIndex)=1/nkinkCreationTime;
    ourIndex=ourIndex+1;
end

figure
semilogy(Gamma,1./energyArray)
title('Semilog plot of inverse kink creation time vs inverse energy')
xlabel('Inverse kink creation time')
ylabel('Inverse energy')
