package com.mycompany.imagej;

import java.awt.Point;

import ij.ImageListener;
import ij.ImagePlus;
import ij.gui.Roi;
import ij.io.Opener;
import ij.process.ImageProcessor;


/**
 * @author Lorcan
 *
 */
public class Unit_tests {
    private Point sideCenter = new Point();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//want to test Autofocus, needs HoloJProcessor rec, ImageProcessor ip, double dx, double dy, double wavelength
		//getSideband, (Point sideCenter, int radius, int scaleFactor, boolean useButterworth)
		//getMaximum position, nothing
		//getsize
		//C:\Users\Lorcan\Desktop\Auto_focus_database\Auto_focus_database\Hol_59_ballicus_antrax_20\
		//this is a blank HoloJPorcessor
		HoloJProcessor rec= new HoloJProcessor(256,256);

		double wavelength=0.000000633;
		double dx=0.00000345;
		double dy=0.00000345;
		double distance=0.5;
		int radius=50;
		int scaleFactor=4;
		boolean useButterworth=false;

		Opener opener = new Opener();  
		String imageFilePath = "C:\\Users\\Lorcan\\Desktop\\Auto_focus_database\\Auto_focus_database\\01_Tristan_hol1\\Hologram.tif";
		ImagePlus imp = opener.openImage(imageFilePath);
		ImageProcessor ip = imp.getProcessor();
		
		distance=HoloJProcessor.AutoFocus(rec, ip ,dx, dy, wavelength);
        Point P = new Point(0,0);
        HoloJProcessor holoRec = rec.getSideband(P,radius,scaleFactor,useButterworth);
        double hologramheight=rec.getHeight();
        double sidebandminheight=hologramheight/scaleFactor;
        
		P = HoloJUtils.getMaximumPosition(rec);
		int size = rec.getSize();
		Point sideCenter=rec.getSidebandCenter(4);
		System.out.println("This is the tests for a blank hologram");
		System.out.println("Autofocus is "+distance+ " the size should be 65536 and it is "+size);
		System.out.println("The maximum position should x=0, y=0 be and it is "+P+"Sidecenter should be 0,0 and it's "+sideCenter);
		System.out.println("The sideband should be "+sidebandminheight+" or greater and it is "+holoRec.getHeight());
		
		//For a normal hologram
		//    public HoloJProcessor(double[] realPixels, int width, int height) {
		double [] maxvalues= new double [65536];
		for(int i=0;i<65536; i++)
		{
			maxvalues[i]=Double.MAX_VALUE;
		}
		rec= new HoloJProcessor(maxvalues, maxvalues, 256, 256);

		distance=HoloJProcessor.AutoFocus(rec, ip ,dx, dy, wavelength);
		System.out.println();

        holoRec = rec.getSideband(P,radius,scaleFactor,useButterworth);
        hologramheight=rec.getHeight();
        sidebandminheight=hologramheight/scaleFactor;
        P = HoloJUtils.getMaximumPosition(rec);
        System.out.println("This is the tests for a max hologram");
		System.out.println("Autofocus not be should be -0.1 and it is "+distance+ " the size should be 65536 and it is "+size);
		System.out.println("The maximum position should x=0, y=0 be and it is "+P+"Sidecenter should be and it's "+sideCenter);
		System.out.println("The sideband should be "+sidebandminheight+" or greater and it is "+holoRec.getHeight());
		
		for(int i=0;i<65536; i++)
		{
			maxvalues[i]=Double.MIN_VALUE;
		}
		rec= new HoloJProcessor(maxvalues, maxvalues, 256, 256);

		distance=HoloJProcessor.AutoFocus(rec, ip ,dx, dy, wavelength);
		System.out.println();
        holoRec = rec.getSideband(P,radius,scaleFactor,useButterworth);
        hologramheight=rec.getHeight();
        sidebandminheight=hologramheight/scaleFactor;
        P = HoloJUtils.getMaximumPosition(rec);
        System.out.println("This is the tests for a min hologram");
		System.out.println("Autofocus should be -0.1 and it is "+distance+ " the size should be 65536 and it is "+size);
		System.out.println("The maximum position should x=0, y=0 be and it is "+P+"Sidecenter should be and it's "+sideCenter);
		System.out.println("The sideband should be "+sidebandminheight+" or greater and it is "+holoRec.getHeight());
		
		
	}

}